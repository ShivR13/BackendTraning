package com.walmart.visitor.service;

import java.util.List;
import java.util.Optional;

import com.walmart.visitor.entity.Visitor;

public interface VisitorService {

	public Visitor registerVisitor(Visitor v);
	public List<Visitor> getAllVisitor();
	public Optional<Visitor> getVistorById(Integer id);
}
