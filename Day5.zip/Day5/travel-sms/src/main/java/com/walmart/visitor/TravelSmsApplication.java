package com.walmart.visitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelSmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelSmsApplication.class, args);
		
	}

}
