package com.walmart.visitor.rest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.visitor.entity.Visitor;
import com.walmart.visitor.service.VisitorService;

@RestController
@RequestMapping("/visitor")
public class VisitorRestController {

	@Autowired
	private VisitorService service;
	
	@PostMapping
	public ResponseEntity<Visitor> createVisitor(@RequestBody Visitor v){
		Visitor registredVisitor=service.registerVisitor(v);
	    ResponseEntity<Visitor> entity=new ResponseEntity<>(registredVisitor,HttpStatus.CREATED);
		return entity;
	}
	
	@GetMapping
	public ResponseEntity<List<Visitor>> getVisitor(){
		List<Visitor> allVisitor = service.getAllVisitor();
	    ResponseEntity<List<Visitor>> entity=new ResponseEntity<>(allVisitor,HttpStatus.OK);
		return entity;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Optional<Visitor>> getVisitorById(@PathVariable Integer id){
		Optional<Visitor> allVisitor = service.getVistorById(id);
	    ResponseEntity<Optional<Visitor>> entity=new ResponseEntity<>(allVisitor,HttpStatus.OK);
		return entity;
	}
}

