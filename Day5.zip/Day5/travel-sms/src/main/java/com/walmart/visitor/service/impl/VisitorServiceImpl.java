package com.walmart.visitor.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.walmart.visitor.entity.Visitor;
import com.walmart.visitor.repository.VisitorRepository;
import com.walmart.visitor.service.VisitorService;

@Service
public class VisitorServiceImpl implements VisitorService {
    
	@Autowired
	private VisitorRepository repo;
	
	@Override
	public Visitor registerVisitor(Visitor v) {
		// TODO Auto-generated method stub
		return repo.save(v);
		
	}

	@Override
	public List<Visitor> getAllVisitor() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Optional<Visitor> getVistorById(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

}
