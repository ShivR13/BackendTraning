package com.walmart.visitor.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Visitor {

	@Id
	int id;
	
	String name;
	
	@Column(unique=true,nullable=false)//additional properties
	String email;
	String whomToMeet;
	String purpose;
	
	
	public Visitor() {
		super();
	}
	public Visitor(int id, String name, String email, String whomToMeet, String purpose) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.whomToMeet = whomToMeet;
		this.purpose = purpose;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWhomToMeet() {
		return whomToMeet;
	}
	public void setWhomToMeet(String whomToMeet) {
		this.whomToMeet = whomToMeet;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	
	
}
