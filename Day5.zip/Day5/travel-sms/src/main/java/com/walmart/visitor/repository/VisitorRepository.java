package com.walmart.visitor.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.walmart.visitor.entity.Visitor;

public interface VisitorRepository extends JpaRepository<Visitor, Integer>{

	
}
