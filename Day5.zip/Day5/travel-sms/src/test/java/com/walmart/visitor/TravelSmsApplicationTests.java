package com.walmart.visitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelSmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
